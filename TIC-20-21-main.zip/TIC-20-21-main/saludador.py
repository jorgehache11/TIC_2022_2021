def saludador():
    nombre=raw_input("Como te llamas? ")
    print("Buenos dias, "+nombre)

saludador()
