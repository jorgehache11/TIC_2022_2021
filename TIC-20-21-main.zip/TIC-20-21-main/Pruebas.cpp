//Esto es un comentario
/*Esto es un comentario de m�s 
lineas*/
//INSTRUCCIONES AL PROCESADOR
#include<stdio.h>
int main(){
    //declaracion de variables
    char salir;
    printf("Hola mundo, cruel");
    printf("\nPresione una tecla");
    scanf("%c",&salir);
    return 0;
    
    
}
