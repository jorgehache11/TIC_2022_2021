def bucle_while_3():
    cont=100
    while(cont>0):
        print("numero "+ str(cont))
        cont=cont-1
        
bucle_while_3()
