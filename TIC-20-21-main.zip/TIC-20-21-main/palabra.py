def palabra():
    nombre=raw_input("Nombre: ")
    apellido=raw_input("Apellido: ")
    print("Buenos dias, "+nombre+" "+apellido)
    
palabra()
