def tabla_while():
    n=input("Que tabla deseas: ")
    cont=0
    print("=================")
    print("=  TABLA DEL "+str(n)+("  ="))
    print("=================")
    while(cont<11):
        print(str(n)+(" x ")+str(cont)+(" = ")+(str(cont)+str(n))
        cont=cont+1
              
tabla_while()

