def contador_3():
    print("Voy a contar desde 10 hasta 0:")
    for cont in range(10,-1,-2):
        print(cont)
        
contador_3()
