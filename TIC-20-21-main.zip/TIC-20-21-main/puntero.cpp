#include<stdio.h>


 int main(){
 	int x;
 	x=2;
 	printf("valor de la variable x= %d",x);
 	printf("\nla direccion de x= %x",&x);
 	
 	
 	
 	return(0);
	
	
}
