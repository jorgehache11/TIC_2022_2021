def bucle_while_4():
    cont=100
    while(cont>0):
        print("numero "+ str(cont))
        cont=cont-1
        
bucle_while_4()
