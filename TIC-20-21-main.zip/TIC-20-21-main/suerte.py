import random

def suerte():
    for cont in range(1,11):
        num=random.randint(1,10)
        print(num)


suerte()
