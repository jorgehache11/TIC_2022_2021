def palabra_2():
    nombre=raw_input("Nombre: ")
    apellido=raw_input("Apellido: ")
    print("Buenos dias, "+nombre+" "+apellido)
    print("Tu lindo nombre empieza por la letra "+nombre[0])
    
palabra_2()
