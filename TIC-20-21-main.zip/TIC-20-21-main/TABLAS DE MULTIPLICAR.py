def TABLAS_MULTIPLICACION():
    numero=input("HOLA, DIME UN NUMERO DEL 1 AL 10")
    print("=======================")
    print("      TABLA DEL "+str(numero))
    print("=======================")
    for cont in range(0,11):
        print(str(numero)+" x "+ str(cont)+" = "+str(numero*cont))
    print("HECHO :)")
    print("-PROGRAMADO POR JORGE HERNANDEZ-")
    
TABLAS_MULTIPLICACION()

    
    
