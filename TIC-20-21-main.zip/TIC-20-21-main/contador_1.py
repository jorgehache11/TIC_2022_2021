def contador_1():
    print("Voy a contar desde 0 hasta 10:")
    for cont in range(0,11):
        print(cont)
        
contador_1()
