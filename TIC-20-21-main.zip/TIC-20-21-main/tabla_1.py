def tabla_1():
    print("*************************")
    print("*      TABLA DEL 7      *")
    print("*************************")
    for cont in range(0,11):
        print("7 x "+str(cont)+" = "+str(7*cont))
    print("Ya esta")
    
tabla_1()
