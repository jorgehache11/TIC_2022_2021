def tabla():
    input("Que tabla deseas: ")
    for cont in range(0,10000000):
        print("No te olvides de estabularme")
       
tabla()
