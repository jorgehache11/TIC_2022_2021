def bucle_while_2():
    cont=0
    while(cont<100):
        print("numero "+ str(cont))
        cont=cont+1
        
bucle_while_2()
