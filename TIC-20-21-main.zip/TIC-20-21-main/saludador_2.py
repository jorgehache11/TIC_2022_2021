def saludador_2():
    nombre=raw_input("Como te llamas? ")
    edad=input("Cuantos anios tienes? ")
    lugar=raw_input("Donde vives? ")
    print("Buenos dias, "+nombre)
    print("tienes "+str(edad)+" anios")
    print("y se que vives en "+lugar)
    print("ten cuidado")

saludador_2()
