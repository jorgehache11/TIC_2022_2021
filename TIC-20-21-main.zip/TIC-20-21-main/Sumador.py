def sumador():
    x=2
    y=3
    print(x+y)

sumador()
    
