def sumador2 ():
    x =input("dime un numero")
    y =input("dime otro numero")
    print x+y
sumador2 ()
